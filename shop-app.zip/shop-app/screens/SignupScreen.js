import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const SignupScreen = () => {
    return (
        <View>
            <Text>signup</Text>
        </View>
    )
}

export default SignupScreen

const styles = StyleSheet.create({})
